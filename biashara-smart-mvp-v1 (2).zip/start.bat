@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  echo Starting Biashara Smart on http://localhost:8080 ...
  start "Biashara Smart" http://localhost:8080
  py -m http.server 8080
  goto :eof
)
where python >nul 2>&1
if %errorlevel%==0 (
  echo Starting Biashara Smart on http://localhost:8080 ...
  start "Biashara Smart" http://localhost:8080
  python -m http.server 8080
  goto :eof
)
echo Python is not installed.
echo Install Python from https://www.python.org/downloads/ and make sure "Add Python to PATH" is checked.
pause
