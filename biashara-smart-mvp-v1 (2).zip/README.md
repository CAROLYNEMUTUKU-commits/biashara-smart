# Biashara Smart — working MVP v1

This is a functional installable web app built from the approved Biashara Smart design.

## Current functionality
- Login/create account flow (local demo)
- Business profile
- Money In
- Money Out with expense categories
- Customers who owe you
- Money Taken Home
- Automatic totals and estimated profit
- Business dashboard
- Monthly report
- Business health score
- CSV export
- Report download
- Local persistence using browser storage
- Installable PWA shell

## Run
Because the service worker needs HTTP, run a simple server from this folder, e.g.:

`python -m http.server 8080`

Then open `http://localhost:8080`.

## Important
This version stores data locally on the device. The next production step is to replace local storage with a secure Supabase backend and real authentication, then package the same app for Android/iOS.
